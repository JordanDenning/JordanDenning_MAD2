//
//  CollectionViewCell.swift
//  ProjectFinal
//
//  Created by Jordan Denning on 3/10/19.
//  Copyright © 2019 Jordan Denning. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var wineNameLabel: UILabel!
    
}
