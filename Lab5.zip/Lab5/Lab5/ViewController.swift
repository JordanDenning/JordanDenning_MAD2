//
//  ViewController.swift
//  Lab5
//
//  Created by Jordan Denning on 3/14/19.
//  Copyright © 2019 Jordan Denning. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    


    @IBOutlet weak var titleText: UITextField!
    @IBOutlet weak var authorText: UITextField!
    
    
    var addedTitle = String()
    var addedAuthor = String()
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "saveSegue" {
            if titleText.text?.isEmpty == false {
                addedTitle=titleText.text!
                addedAuthor=authorText.text!
            }
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

