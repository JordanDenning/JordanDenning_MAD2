//
//  BookDataController.swift
//  Lab5
//
//  Created by Jordan Denning on 3/14/19.
//  Copyright © 2019 Jordan Denning. All rights reserved.
//

import Foundation
import Firebase

class BookDataController {
    var ref: DatabaseReference!
    
    var bookLib = [Book]()
    
    var onDataUpdate: ((_ data: [Book]) -> Void)?
    
    func setupFirebaseListener(){
        //        print("HI")
        ref = Database.database().reference().child("Book")
        print(ref)
        //        print(ref)
        //set up a listener for Firebase data change events
        //this event will fire with the initial data and then all data changes
        ref.observe(DataEventType.value, with: {snapshot in
            self.bookLib.removeAll()
            //DataSnapshot represents the Firebase data at a given time
            //loop through all the child data nodes
            for snap in snapshot.children.allObjects as! [DataSnapshot]{
                //print(snap)
                let bookID = snap.key
                if let bookDict = snap.value as? [String: String], //get value as a Dictionary
                    
                    let bookTitle = bookDict["title"],
                    let bookAuthor = bookDict["author"]

                {
                    //                    print("HI")
                    let newBook = Book(id: bookID , title: bookTitle, author: bookAuthor )
                    //add recipe to recipes array
                    self.bookLib.append(newBook)
                    //                    print(newWine)
                }
            }
            //passing the results to the onDataUpdate closure
            self.onDataUpdate?(self.bookLib)
        })
    }
    
    func getBooks()->[Book]{
//        print("WOHOOOO BOOKLIB")
        return bookLib
        
    }
    
    func deleteBook(bookID: String){
        // Delete the object from Firebase
        //        print("Trying to delete")
        //        print(wineID)
        ref.child(bookID).removeValue()
    }
    
    func addBook(title: String, author: String){
        //create Dictionary
        let newBookDict = ["title": title, "author": author]
        
        //        print(newWineDict["name"]!)
        //        print(ref)
        //create a new ID
        let bookRef = ref.childByAutoId()
        
        //write data to the new ID in Firebase
        bookRef.setValue(newBookDict)
        print("ADDED")
    }

    
}
