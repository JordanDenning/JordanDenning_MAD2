//
//  Book.swift
//  Lab5
//
//  Created by Jordan Denning on 3/14/19.
//  Copyright © 2019 Jordan Denning. All rights reserved.
//

import Foundation
import Firebase

struct Book {
    var id: String
    var title: String
    var author: String
    
    init(id: String, title: String, author: String) {
        self.id = id
        self.title = title
        self.author = author
    }
}

