//
//  Movies.swift
//  JDMidterm
//
//  Created by admin on 3/14/19.
//  Copyright © 2019 admin. All rights reserved.
//

import Foundation

struct Movies: Codable{
    var name: String
    var url: String
}
